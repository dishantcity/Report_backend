package com.project.ahom.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

   // @NotBlank(message = "Title is required")
    private String title;

    //@NotBlank(message = "Content is required")
    private String content;



}
