package com.project.ahom.dto;

public class ReportDTO {
}
