package com.project.ahom.service;

import com.project.ahom.entity.Report;
import com.project.ahom.repo.ReportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import java.util.List;

@Service
public class ReportService {

    @Autowired
    private ReportRepository reportRepository;

    public List<Report> getAllReports() {
        return reportRepository.findAll();
    }

//    public Report getReportById(Long id) {
//        return reportRepository.findById(id)
//                .orElseThrow(() -> new Resource("Report not found with id " + id));
//    }

    public Report createReport(Report report) {
        // Perform server-side validation here
        // Example: Check for unique constraints, validate data, etc.
        // You can use javax.validation annotations or custom validation logic

        return reportRepository.save(report);
    }

    public Report updateReport(Long id, Report report) {
        Report existingReport = getReportById(id);

        // Update fields and perform validation if needed

        return reportRepository.save(existingReport);
    }



    public void deleteReport(Long id) {
        Report report = getReportById(id);
        reportRepository.delete(report);
    }

//    private Report getReportById(Long id) {
//        return null;
//    }
}
